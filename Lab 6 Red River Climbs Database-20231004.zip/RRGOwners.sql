INSERT INTO owners (owner_name)
VALUES ('Red River Gorge Climbers Coalition'),
       ('United States Forest Service'),
       ('John and Elizabeth Muir'),
       ('Other Private Ownership');
