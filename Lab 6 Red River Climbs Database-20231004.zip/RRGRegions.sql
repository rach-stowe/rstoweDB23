INSERT INTO regions (region_name, owner_name)
VALUES ('Muir Valley',              'John and Elizabeth Muir'),
       ('Gray''s Branch Region',    'United States Forest Service'),
       ('Lower Gorge Region',       'United States Forest Service'),
       ('Northern Gorge Region',    'United States Forest Service'),
       ('Middle Gorge Region',      'United States Forest Service'),
       ('Upper Gorge Region',       'United States Forest Service'),
       ('Eastern Gorge Region',     'United States Forest Service'),
       ('Tunnel Ridge Road Region', 'United States Forest Service'),
       ('Natural Bridge Region',    'United States Forest Service'),
       ('Southern Region',          'Red River Gorge Climbers Coalition'),
       ('Miller Fork',              'United States Forest Service'),
       ('Foxtown',                  'Other Private Ownership');
